---
name: Feature request
about: Suggest an idea for this project
labels: 

---

Please post feature requests in [this](https://github.com/TomGrobbe/vMenu/issues/115) issue instead of creating a new issue for it.

Any requests _not_ posted in that linked issue (#115) may result in you getting banned from this repository.
